# 🎓 A7MED Ashraf LMS

منصة تعلم برمجي متكاملة بتقنية **Evo LMS** — منصة حديثة لإدارة الدورات التعليمية والفيديوهات والامتحانات.

## ⚡ المميزات

- ✅ لوحة تحكم Admin كاملة
- ✅ رفع فيديوهات تعليمية
- ✅ إنشاء امتحانات متعددة الخيارات
- ✅ إدارة الطلاب والتقدم
- ✅ تصميم عصري ومتجاوب
- ✅ مصادقة JWT آمنة

## 🔐 بيانات الدخول

| الحقل | القيمة |
|-------|--------|
| اسم المستخدم | `A7MED ashraf` |
| كلمة المرور | `Af.12345` |

## 🚀 خطوات التشغيل

### 1. المتطلبات
- Node.js (v18+)
- MongoDB

### 2. التثبيت
```bash
npm install
```

### 3. تشغيل MongoDB
```bash
mongod
```

### 4. تشغيل السيرفر
```bash
npm run dev
```

### 5. الفتح في المتصفح
```
http://localhost:5000
```

## 📁 هيكل المشروع

```
a7med-ashraf-lms/
├── server/
│   ├── server.js
│   ├── routes/
│   │   ├── auth.js
│   │   ├── courses.js
│   │   └── exams.js
│   └── models/
│       ├── Course.js
│       ├── Exam.js
│       └── User.js
├── client/
│   ├── index.html
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── app.js
├── uploads/
│   └── videos/
├── .env
├── package.json
└── README.md
```

## 🌐 الاستضافة السحابية

يمكن رفع المشروع على:
- **Backend**: Render, Railway, DigitalOcean
- **Database**: MongoDB Atlas
- **Frontend**: Vercel, Netlify

---
**صنع بحب ❤️ بواسطة A7MED Ashraf**
